import React, { useState } from "react";

const ScanPage = () => {
  const [serverPath, setServerPath] = useState("");
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  const BACKEND_URL = "http://localhost:8081";

  const addToHistory = (type, input, data) => {
    const entry = {
      id: Date.now(),
      type,
      input,
      data,
      date: new Date().toLocaleString(),
    };
    setHistory((prev) => [entry, ...prev]);
  };

  const handleScanServer = async () => {
    if (!serverPath) return alert("Enter server folder path!");
    setLoading(true);
    setResult(`Scanning server folder: ${serverPath} ...`);

    try {
      const res = await fetch(
        `${BACKEND_URL}/api/scan?path=${encodeURIComponent(serverPath)}`
      );
      const data = await res.json();
      setResult(data);
      addToHistory("Server Folder", serverPath, data);
    } catch (err) {
      setResult({ error: err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleUploadScan = async () => {
    if (!file) return alert("Select a ZIP file!");
    setLoading(true);
    setResult(`Uploading and scanning file: ${file.name} ...`);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${BACKEND_URL}/api/upload-scan`, {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setResult(data);
      addToHistory("ZIP Upload", file.name, data);
    } catch (err) {
      setResult({ error: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        fontFamily: "'Segoe UI', sans-serif",
        background: "linear-gradient(135deg,#f5f7fa,#c3cfe2)",
        minHeight: "100vh",
        padding: "40px",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          background: "white",
          borderRadius: "20px",
          boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
          padding: "40px",
        }}
      >
        <h1
          style={{
            textAlign: "center",
            marginBottom: "40px",
            fontSize: "2.5rem",
            color: "#2b4eff",
          }}
        >
          Cloud Migration Scanner
        </h1>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "30px",
          }}
        >
          {/* Left Side: Scan Inputs */}
          <div>
            <div
              style={{
                background: "#f9faff",
                padding: "25px",
                borderRadius: "15px",
                marginBottom: "30px",
                boxShadow: "0 5px 15px rgba(0,0,0,0.05)",
              }}
            >
              <h3 style={{ color: "#2b4eff" }}>Scan Server Folder</h3>
              <input
                type="text"
                placeholder="Enter path e.g. D:/wipro/backend"
                value={serverPath}
                onChange={(e) => setServerPath(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  borderRadius: "10px",
                  border: "1px solid #ccc",
                  margin: "15px 0",
                }}
              />
              <button
                onClick={handleScanServer}
                disabled={loading}
                style={{
                  background: "#2b4eff",
                  color: "white",
                  border: "none",
                  borderRadius: "10px",
                  padding: "12px 20px",
                  cursor: "pointer",
                  width: "100%",
                  fontWeight: "bold",
                }}
              >
                Scan Folder
              </button>
            </div>

            <div
              style={{
                background: "#f9faff",
                padding: "25px",
                borderRadius: "15px",
                boxShadow: "0 5px 15px rgba(0,0,0,0.05)",
              }}
            >
              <h3 style={{ color: "#2b4eff" }}>Upload ZIP & Scan</h3>
              <input
                type="file"
                accept=".zip"
                onChange={(e) => setFile(e.target.files[0])}
                style={{ margin: "15px 0" }}
              />
              <button
                onClick={handleUploadScan}
                disabled={loading}
                style={{
                  background: "#2b4eff",
                  color: "white",
                  border: "none",
                  borderRadius: "10px",
                  padding: "12px 20px",
                  cursor: "pointer",
                  width: "100%",
                  fontWeight: "bold",
                }}
              >
                Upload & Scan
              </button>
            </div>
          </div>

          {/* Right Side: Result + History */}
          <div>
            <div
              style={{
                background: "#f9faff",
                padding: "25px",
                borderRadius: "15px",
                marginBottom: "30px",
                boxShadow: "0 5px 15px rgba(0,0,0,0.05)",
                height: "300px",
                overflow: "auto",
              }}
            >
              <h3 style={{ color: "#2b4eff" }}>Scan Result</h3>
              <pre
                style={{
                  background: "#fff",
                  padding: "15px",
                  borderRadius: "10px",
                  border: "1px solid #ddd",
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                  maxHeight: "220px",
                  overflow: "auto",
                }}
              >
                {result ? JSON.stringify(result, null, 2) : "No scan yet."}
              </pre>
            </div>

            <div
              style={{
                background: "#f9faff",
                padding: "25px",
                borderRadius: "15px",
                boxShadow: "0 5px 15px rgba(0,0,0,0.05)",
                height: "300px",
                overflow: "auto",
              }}
            >
              <h3 style={{ color: "#2b4eff" }}>Scan History</h3>
              {history.length === 0 && <p>No history yet.</p>}
              <ul style={{ padding: 0, listStyle: "none" }}>
                {history.map((h) => (
                  <li
                    key={h.id}
                    onClick={() => setResult(h.data)}
                    style={{
                      padding: "10px",
                      background: "white",
                      borderRadius: "8px",
                      border: "1px solid #ddd",
                      marginBottom: "10px",
                      cursor: "pointer",
                      transition: "0.2s",
                    }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.background = "#eaf0ff")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.background = "white")
                    }
                  >
                    <strong>{h.type}</strong> - {h.input}
                    <div style={{ fontSize: "12px", color: "#555" }}>
                      {h.date}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScanPage;
