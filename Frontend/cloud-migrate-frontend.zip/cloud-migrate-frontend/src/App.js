import ScanPage from "./Components/ScanPage";

function App() {
  return <ScanPage />;
}

export default App;
